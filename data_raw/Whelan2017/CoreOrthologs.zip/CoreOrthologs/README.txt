Place folder MGEN in Hamstr blast directory and Ctenophora_hmmer3 in core_ortholog directory. Please refer to
Hamstr manual for more information.