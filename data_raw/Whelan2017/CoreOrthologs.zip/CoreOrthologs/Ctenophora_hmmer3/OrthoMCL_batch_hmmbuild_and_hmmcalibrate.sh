for FILENAME in *.fa
do
ORTHOLOGY_GROUP=`echo $FILENAME | cut -d . -f 1`
#sed -i "s/>/>$ORTHOLOGY_GROUP|/g" $FILENAME
perl /usr/local/bin/fasta2stockholm.pl $FILENAME > $ORTHOLOGY_GROUP.stockholm

echo Starting hmmbuild...
hmmbuild --amino --cpu 7 $ORTHOLOGY_GROUP.hmm $ORTHOLOGY_GROUP.stockholm

echo Starting hmmconvert...
hmmconvert -2 $ORTHOLOGY_GROUP.hmm > $ORTHOLOGY_GROUP.hmm2
rm -rf $ORTHOLOGY_GROUP.hmm
mv $ORTHOLOGY_GROUP.hmm2 $ORTHOLOGY_GROUP.hmm

echo Starting hmmcalibrate...
hmmcalibrate --cpu 7 $ORTHOLOGY_GROUP.hmm

echo Starting hmmconvert...
hmmconvert --outfmt 3/a $ORTHOLOGY_GROUP.hmm > $ORTHOLOGY_GROUP.hmm3a
rm -rf $ORTHOLOGY_GROUP.hmm
mv $ORTHOLOGY_GROUP.hmm3a $ORTHOLOGY_GROUP.hmm

done

rm -rf *.stockholm
cat *.fa > ../Ctenophora_hmmer3.fa
